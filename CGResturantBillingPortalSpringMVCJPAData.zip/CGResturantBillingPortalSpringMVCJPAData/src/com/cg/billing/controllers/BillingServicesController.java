package com.cg.billing.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.services.BillingServices;

@Controller
public class BillingServicesController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerAccount(@ModelAttribute Customer customer){
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessPage","customer",customer);
	}

}
