package com.cg.billing.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Customer;
@Component("customereDAO")
public class CustomerDAOImpl implements CustomerDAO{
	@Autowired
	private EntityManagerFactory entityManagerFactory;

	@Override
	public Customer save(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer;
	}

	@Override
	public boolean update(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(customer);
		entityManager.getTransaction().commit();
		entityManager.close();

		return false;
	}

	@Override
	public Customer findOne(int customerId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Customer.class, customerId);

	}


	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> findAll() {
		Query query=entityManagerFactory.createEntityManager().createQuery("from Customer a");
		return (List<Customer>)query.getResultList();
	}
}